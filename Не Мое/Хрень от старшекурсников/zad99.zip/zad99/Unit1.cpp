//---------------------------------------------------------------------------

#include <math.h>
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button1Click(TObject *Sender)
{
  int i,n;
  double h,nn,b0=1,c0=-1,a=1,b=1,c=-2,an=0,cn=1,f0,f,cSH[10000],fSH[10000],ut,u[10000],A,B;
  Chart1->Series[0]->Clear();
  Chart1->Series[1]->Clear();
  Chart2->Series[0]->Clear();

  nn=StrToInt(Edit2->Text);
  if(nn>=10000) nn=10000;
  n=nn;
  h=1/nn;

  A=StrToFloat(Edit1->Text);
  B=StrToFloat(Edit3->Text);

//  f0=h*A;
  f0=h*A+h*h/2;
  fSH[0]=f0;
  fSH[1]=(h*h/((1+h)*(1+h)))-a*f0/c0;
  fSH[n]=B;
  cSH[0]=c0;
  cSH[1]=c-a*b0/cSH[0];
  cSH[n]=1;
  u[n]=fSH[n]/cSH[n];

  for(i=2;i<n;i++)
  {
        f=h*h/((1+i*h)*(1+i*h));
        cSH[i]=c-a*b/cSH[i-1];
        fSH[i]=f-a*fSH[i-1]/cSH[i-1];
  }

  for(i=n-1;i>=0;i--)
  {
        u[i]=fSH[i]-b*u[i+1]/cSH[i];
  }

  for(i=0;i*h<1;i++)
  {
        Chart1->Series[0]->AddXY(i*h,u[i],"",clRed);
        ut=(-1)*(-log(1+i*h)+(A+1)*i*h+B-A+log(2)-1)+2*B;
        Chart1->Series[1]->AddXY(i*h,ut,"",clGreen);
        Label5->Caption="�����������: "+FloatToStr(/*-u[i]+ut*/(-1)*(-log(1+0*h)+(A+1)*0*h+B-A+log(2)-1)+2*B-u[0]);
        Chart2->Series[0]->AddXY(i*h,-u[i]+ut,"",clGreen);
  }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormResize(TObject *Sender)
{
  Chart1->Align=alLeft;
  Chart2->Align=alClient;
}
//---------------------------------------------------------------------------
